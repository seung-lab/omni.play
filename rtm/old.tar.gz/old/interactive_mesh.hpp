//
// Copyright (C) 2012  Aleksandar Zlateski <zlateski@mit.edu>
// ----------------------------------------------------------
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

#ifndef ZI_MESHING_INTERACTIVE_MESH_HPP
#define ZI_MESHING_INTERACTIVE_MESH_HPP

#include "detail/log.hpp"
#include "types.hpp"
#include "files.hpp"
#include "chunk_mem_io.hpp"
#include "fmesh_io.hpp"
#include "smesh_io.hpp"

#include <zi/bits/hash.hpp>
#include <zi/bits/array.hpp>
#include <zi/utility/for_each.hpp>
#include <zi/concurrency.hpp>

#include <map>
#include <set>
#include <list>

namespace zi {
namespace mesh {

class interactive_mesh: non_copyable
{
private:
    struct store_task: non_copyable
    {
        vec3u coor_;
        vec3u from_;
        vec3u to_;
        chunk_type_ptr d_;
        mask_type_ptr m_;

        store_task( vec3u coor,
                    vec3u from,
                    vec3u to,
                    chunk_type_ptr d,
                    mask_type_ptr m = mask_type_ptr() )
            : coor_(coor)
            , from_(from)
            , to_(to)
            , d_(d)
            , m_(m)
        { }
    };

private:
    const uint32_t  id_;

    zi::rwmutex     mutex_;

    zi::array<std::set<vec3u>,9> to_remesh_      ;
    zi::array<zi::mutex,9>       to_remesh_mutex_;

    smesh_io smesh_io_;
    fmesh_io fmesh_io_;
    chunk_io chunk_io_;

    zi::rwmutex                       chunk_updates_m_;
    zi::array<zi::rwmutex,9>          mipn_updates_m_ ;

    zi::thread                        up_loop_;

    std::map<vec3u, std::list<store_task*> > store_      ;
    zi::mutex                                store_mutex_;

    bool                                     done_;

private:
    void register_store_task_nl( vec3u coor,
                                 vec3u from,
                                 vec3u to,
                                 chunk_type_ptr d,
                                 mask_type_ptr m = mask_type_ptr() )
    {
        vec3u chunk_coord(from[0] / CHUNK_SIZE, from[1] / CHUNK_SIZE, from[2] / CHUNK_SIZE );
        store_[chunk_coord].push_back( new store_task( coor, from, to, d, m ) );
    }


public:
    interactive_mesh( uint32_t id )
        : id_(id)
        , mutex_()
        , to_remesh_()
        , to_remesh_mutex_()
        , smesh_io_(id)
        , fmesh_io_(id)
        , chunk_io_(id)
        , chunk_updates_m_()
        , mipn_updates_m_()
        , up_loop_(zi::run_fn(zi::bind(&interactive_mesh::up_loop, this) ))
        , store_()
        , store_mutex_()
        , done_(false)
    {
        up_loop_.start();
    }

    ~interactive_mesh()
    {
        {
            zi::rwmutex::write_guard g(mutex_);
            done_ = true;
        }
        up_loop_.join();
        LOG(out) << "   Interactive handler for cell " << id_ << " closed\n";
    }

private:
    void schedule_remesh( const vec3u& c, uint32_t mip )
    {
        if ( mip >= 9 )
        {
            return;
        }

        zi::mutex::guard g(to_remesh_mutex_[mip]);
        to_remesh_[mip].insert(c);
    }

    void schedule_remesh_around( const vec3u& c )
    {
        uint32_t fx = ( c[0] > 0 ) ? c[0] - 1 : c[0];
        uint32_t fy = ( c[1] > 0 ) ? c[1] - 1 : c[1];
        uint32_t fz = ( c[2] > 0 ) ? c[2] - 1 : c[2];

        zi::mutex::guard g(to_remesh_mutex_[0]);

        for ( uint32_t x = fx; x <= c[0]; ++x )
        {
            for ( uint32_t y = fy; y <= c[1]; ++y )
            {
                for ( uint32_t z = fz; z <= c[2]; ++z )
                {
                    to_remesh_[0].insert(vec3u(x,y,z));
                }
            }
        }
    }

    void swap_to_remesh(std::set<vec3u>& s, uint32_t mip)
    {
        zi::mutex::guard g1(to_remesh_mutex_[mip]);

        std::set<vec3u> empty;

        std::swap( to_remesh_[mip], s );
        std::swap( empty, to_remesh_[mip] );
    }

private:
    std::size_t hash( const uint32_t* data, std::size_t len )
    {
        zi::hash<std::size_t> hasher;
        std::size_t seed = 0;

        for ( std::size_t i = 0; i < len; ++i )
        {
            if ( data[i] == id_ )
            {
                seed ^= hasher(i) + 0x9e3779b9 + (seed<<6) + (seed>>2);
            }
        }
        return seed;
    }

    void subvolume_update( vec3u coor,
                           vec3u from,
                           vec3u to,
                           chunk_type_ptr d,
                           mask_type_ptr m = mask_type_ptr() )
    {
        uint32_t x0 = coor[0];
        uint32_t y0 = coor[1];
        uint32_t z0 = coor[2];

        uint32_t fx = from[0];
        uint32_t fy = from[1];
        uint32_t fz = from[2];

        uint32_t tx = to[0];
        uint32_t ty = to[1];
        uint32_t tz = to[2];

        ZI_ASSERT(fx/CHUNK_SIZE==tx/CHUNK_SIZE);
        ZI_ASSERT(fy/CHUNK_SIZE==ty/CHUNK_SIZE);
        ZI_ASSERT(fz/CHUNK_SIZE==tz/CHUNK_SIZE);

        vec3u chunk_coord(fx / CHUNK_SIZE, fy / CHUNK_SIZE, fz / CHUNK_SIZE );

        chunk_type_ptr chunk;

        // get old chunk and old hashes!
        chunk = chunk_io_.read(chunk_coord, true);

        //std::size_t old_hash = hash(chunk->data(), chunk->num_elements());

        if ( !m )
        {

            if ( chunk->operator[](indices
                                   [range(fz%CHUNK_SIZE,tz%CHUNK_SIZE+1)]
                                   [range(fy%CHUNK_SIZE,ty%CHUNK_SIZE+1)]
                                   [range(fx%CHUNK_SIZE,tx%CHUNK_SIZE+1)])
                 != d->operator[](indices
                                  [range(fz-z0,tz-z0+1)]
                                  [range(fy-y0,ty-y0+1)]
                                  [range(fx-x0,tx-x0+1)]) )
            {

                // update the chunk
                chunk->operator[](indices
                                  [range(fz%CHUNK_SIZE,tz%CHUNK_SIZE+1)]
                                  [range(fy%CHUNK_SIZE,ty%CHUNK_SIZE+1)]
                                  [range(fx%CHUNK_SIZE,tx%CHUNK_SIZE+1)])
                    = d->operator[](indices
                                    [range(fz-z0,tz-z0+1)]
                                    [range(fy-y0,ty-y0+1)]
                                    [range(fx-x0,tx-x0+1)]);

                chunk_io_.write(chunk, chunk_coord);
                schedule_remesh_around(chunk_coord);
            }
        }
        else
        {

            bool do_it = false;
            bool modified[2][2][2] = {{{0,0},{0,0}},{{0,0},{0,0}}};

            for ( uint32_t oz = fz-z0, dz = fz%CHUNK_SIZE; oz <= tz-z0; ++oz, ++dz )
            {
                for ( uint32_t oy = fy-y0, dy = fy%CHUNK_SIZE; oy <= ty-y0; ++oy, ++dy )
                {
                    for ( uint32_t ox = fx-x0, dx = fx%CHUNK_SIZE; ox <= tx-x0; ++ox, ++dx )
                    {
                        if ( (*m)[oz][oy][ox] && ( (*d)[oz][oy][ox] != (*chunk)[dz][dy][dx] ) )
                        {
                            do_it = true;
                            modified[dx==0][dy==0][dz==0] = true;
                            (*chunk)[dz][dy][dx] = (*d)[oz][oy][ox];
                        }
                    }
                }
            }

            if ( do_it )
            {
                chunk_io_.write(chunk, chunk_coord);
                schedule_remesh_around(chunk_coord);
            }
        }

    }

    // void chunk_update_internal( vec3u chunk_coord, chunk_ref_ptr d )
    // {
    //     chunk_type_ptr chunk;

    //     // get old chunk and old hashes!
    //     chunk = chunk_io_.read(chunk_coord, true);

    //     std::size_t old_hash = hash(chunk->data(), chunk->num_elements());

    //     // update the chunk
    //     chunk->operator[](indices[range(0,CHUNK_SIZE)][range(0,CHUNK_SIZE)][range(0,CHUNK_SIZE)])
    //         = d->operator[](indices[range(0,CHUNK_SIZE)][range(0,CHUNK_SIZE)][range(0,CHUNK_SIZE)]);


    //     // get new hashes
    //     std::size_t new_hash = hash(chunk->data(), chunk->num_elements());

    //     if ( old_hash != new_hash )
    //     {
    //         chunk_io_.write(chunk, chunk_coord);
    //         schedule_remesh_around(chunk_coord);
    //     }
    // }

    void volume_update_internal(uint32_t x, uint32_t y, uint32_t z,
                                uint32_t w, uint32_t h, uint32_t d,
                                chunk_type_ptr c, mask_type_ptr m = mask_type_ptr() )
    {
        uint32_t x0 = x;
        uint32_t y0 = y;
        uint32_t z0 = z;
        uint32_t x1 = x + w - 1;
        uint32_t y1 = y + h - 1;
        uint32_t z1 = z + d - 1;

        uint32_t mx0 = x0 / CHUNK_SIZE;
        uint32_t my0 = y0 / CHUNK_SIZE;
        uint32_t mz0 = z0 / CHUNK_SIZE;
        uint32_t mx1 = x1 / CHUNK_SIZE;
        uint32_t my1 = y1 / CHUNK_SIZE;
        uint32_t mz1 = z1 / CHUNK_SIZE;

        zi::task_manager::simple tm(16);

        tm.start();

        for ( uint32_t i = mx0; i <= mx1; ++i )
        {
            for ( uint32_t j = my0; j <= my1; ++j )
            {
                for ( uint32_t k = mz0; k <= mz1; ++k )
                {
                    uint32_t fromx = std::max( x0, i * CHUNK_SIZE );
                    uint32_t tox   = std::min( x1, (i+1) * CHUNK_SIZE - 1 );

                    uint32_t fromy = std::max( y0, j * CHUNK_SIZE );
                    uint32_t toy   = std::min( y1, (j+1) * CHUNK_SIZE - 1 );

                    uint32_t fromz = std::max( z0, k * CHUNK_SIZE );
                    uint32_t toz   = std::min( z1, (k+1) * CHUNK_SIZE - 1 );

                    tm.insert( zi::run_fn(
                                   zi::bind( &interactive_mesh::subvolume_update, this,
                                             vec3u(x,y,z), vec3u(fromx, fromy, fromz),
                                             vec3u(tox, toy, toz), c, m ) ) );
                }
            }
        }

        tm.join();
    }

private:
    void process_chunk( const vec3u& c )
    {
        chunk_type_ptr chunk = chunk_io_.read_extended(c);

        zi::mesh::marching_cubes<int32_t> mc;
        mc.marche(reinterpret_cast<int32_t*>(chunk->data()),
                  (CHUNK_SIZE+1), (CHUNK_SIZE+1), (CHUNK_SIZE+1));



        vec4u mcoord( c[0], c[1], c[2], 0);
        vec3u next(c[0]/2, c[1]/2, c[2]/2);

        if ( mc.count(id_) )
        {
            int_mesh im;
            im.add(mc.get_triangles(id_));

            simplifier<double> s;
            im.fill_simplifier<double>(s);

            s.prepare();
            s.optimize(s.face_count()/10, 1e-12 );

            std::vector< zi::vl::vec3d > points ;
            std::vector< zi::vl::vec3d > normals;
            std::vector< vec3u >         faces  ;

            s.get_faces(points, normals, faces);
            mesh_type_ptr fmd( new mesh_type );
            fmd->add(points, normals, faces);

            //std::cout << "Saving Chunk Coord: " << mcoord << "\n";

            fmesh_io_.write(fmd, mcoord);
            if ( smesh_io_.write(mcoord, s) )
            {
            }
            schedule_remesh(next,1);
        }
        else
        {
            ///std::cout << "Erasing Chunk Coord: " << mcoord << "\n";
            fmesh_io_.remove(mcoord);
            if ( smesh_io_.remove(mcoord) )
            {
            }
            schedule_remesh(next,1);
        }
    }

    void process_chunk_mipn( const vec3u& c, uint32_t mip )
    {
        vec4u mcoord( c[0], c[1], c[2], mip);
        vec3u next(c[0]/2, c[1]/2, c[2]/2);

        //std::cout << "Processing Chunk Coord: " << mcoord << "\n";

        vl::vec3d offset = vl::vec3d(CHUNK_SIZE<<mip,CHUNK_SIZE<<mip,CHUNK_SIZE<<mip);
        mesh_type_ptr fmd = fmesh_io_.read_from_lower(mcoord, offset);

        if ( fmd )
        {
            simplifier<double> s;
            fmd->fill_simplifier<double>(s);

            s.prepare();
            s.optimize(s.face_count()/8, (1<<(mip-1)));

            std::vector< zi::vl::vec3d > points ;
            std::vector< zi::vl::vec3d > normals;
            std::vector< vec3u >         faces  ;

            s.get_faces(points, normals, faces);
            mesh_type_ptr nfmd( new mesh_type );
            nfmd->add(points, normals, faces);

            //std::cout << "Saving Chunk Coord: " << mcoord << "\n";

            fmesh_io_.write(nfmd, mcoord);
            if ( smesh_io_.write(mcoord, s) )
            {
            }
            schedule_remesh(next,mip+1);
        }
        else
        {
            //std::cout << "Erasing Chunk Coord: " << mcoord << "\n";
            fmesh_io_.remove(mcoord);
            if ( smesh_io_.remove(mcoord) )
            {
            }
            schedule_remesh(next,mip+1);
        }
    }

private:
    void up_loop()
    {
        bool done = false;
        while (!done)
        {
            zi::this_thread::usleep(100000);
            {
                zi::rwmutex::read_guard g(mutex_);
                done = done_;
                process_up();
            }
        }
    }

    void process_up()
    {
        zi::task_manager::simple tm(16);

        //std::cout << "Will Process UP!" << std::endl;

        {
            zi::rwmutex::write_guard g1(chunk_updates_m_);
            zi::rwmutex::write_guard g2(mipn_updates_m_[0]);

            std::set<vec3u> to_remesh;
            swap_to_remesh(to_remesh,0);

            if ( to_remesh.size() == 0 )
            {
                return;
            }

            LOG(out) << "IM(" << id_ << ")" << ": processing MIP: 0" << std::endl;

            tm.start();

            FOR_EACH( it, to_remesh )
            {
                tm.insert( zi::run_fn( zi::bind( &interactive_mesh::process_chunk, this, *it ) ) );
            }
            tm.join();
        }

        for ( uint32_t mip = 1; mip < 9; ++mip )
        {
            zi::rwmutex::write_guard g1(mipn_updates_m_[mip-1]);
            zi::rwmutex::write_guard g2(mipn_updates_m_[mip]);

            LOG(out) << "IM(" << id_ << ")" << ": processing MIP: " << mip << std::endl;

            std::set<vec3u> to_remesh;
            swap_to_remesh(to_remesh,mip);

            if ( to_remesh.size() == 0 )
            {
                return;
            }

            tm.start();

            FOR_EACH( it, to_remesh )
            {
                tm.insert( zi::run_fn( zi::bind( &interactive_mesh::process_chunk_mipn,
                                                 this, *it, mip )));
            }

            tm.join();
        }
    }

public:
    // void volume_update(uint32_t x, uint32_t y, uint32_t z,
    //                    uint32_t w, uint32_t h, uint32_t d,
    //                    const char* data)
    // {
    //     zi::rwmutex::read_guard g(mutex_); // YES this is read guard (reading the dir structure)

    //     chunk_ref_ptr c( new chunk_type_ref(reinterpret_cast<const uint32_t*>(data),
    //                                         extents[d][h][w]) );

    //     {
    //         zi::rwmutex::write_guard g1(chunk_updates_m_);
    //         volume_update_internal(x, y, z, w, h, d, c);
    //     }

    //     //process_up();
    // }

    void chunk_update( uint32_t x, uint32_t y, uint32_t z,
                       const char* data, const char* mask = 0 )
    {
        zi::rwmutex::read_guard g(mutex_); // YES this is read guard (reading the dir structure)

        chunk_ref_ptr c( new chunk_type_ref(reinterpret_cast<const uint32_t*>(data),
                                            extents[CHUNK_SIZE][CHUNK_SIZE][CHUNK_SIZE]) );

        {
            zi::rwmutex::write_guard g1(chunk_updates_m_);
            //chunk_update_internal( vec3u(x,y,z), c );
        }

        //process_up();
    }

    void volume_update_inner(uint32_t x, uint32_t y, uint32_t z,
                             uint32_t w, uint32_t h, uint32_t d,
                             uint32_t border_width, const char* data,
                             const char* mask = 0)
    {
        zi::rwmutex::read_guard g1(mutex_); // YES this is read guard (reading the dir structure)

        uint32_t ow = border_width;
        uint32_t dw = 2*ow;

        chunk_type_ptr c(new chunk_type(extents[d-dw][h-dw][w-dw]));

        chunk_ref_ptr corig( new chunk_type_ref(reinterpret_cast<const uint32_t*>(data),
                                                extents[d][h][w]) );

        c->operator[](indices[range(0,d-dw)][range(0,h-dw)][range(0,w-dw)])
            = corig->operator[](indices[range(ow,d-ow)][range(ow,h-ow)][range(ow,w-ow)]);

        mask_type_ptr m;

        if ( mask )
        {
            m = mask_type_ptr( new mask_type(extents[w-dw][h-dw][d-dw]) );
            mask_type_ref morig( mask, extents[d][h][w] );

            m->operator[](indices[range(0,d-dw)][range(0,h-dw)][range(0,w-dw)])
                = morig[indices[range(ow,d-ow)][range(ow,h-ow)][range(ow,w-ow)]];
        }

        {
            zi::rwmutex::write_guard g(chunk_updates_m_);

            std::cout << "Chunk Data Update!" << std::endl;

            volume_update_internal(x+ow, y+ow, z+ow, w-dw, h-dw, d-dw, c, m);
        }

        //process_up();
    }

    std::size_t get_hash( const vec4u& c )
    {
        zi::rwmutex::read_guard g(mutex_);
        return smesh_io_.get_hash(c);
    }

    std::size_t get_hash( uint32_t x, uint32_t y, uint32_t z, uint32_t mip )
    {
        return get_hash( vec4u(x,y,z,mip) );
    }

    std::size_t get_mesh( const vec4u& c, std::string& ret )
    {
        zi::rwmutex::read_guard g(mutex_);
        return smesh_io_.read(c, ret);
    }

    void get_hashes( std::vector<int64_t>& r, const std::vector<vec4u>& c )
    {
        zi::rwmutex::read_guard g(mutex_);
        r.resize(c.size());

        for ( std::size_t i = 0; i < c.size(); ++i )
        {
            r[i] = static_cast<int64_t>(smesh_io_.get_hash(c[i]));
        }
    }

    std::size_t get_mesh_if_different( const vec4u& c, std::string& ret, std::size_t h )
    {
        zi::rwmutex::read_guard g(mutex_);
        return smesh_io_.read_if_different(c, ret, h);
    }

    void clear()
    {
        zi::rwmutex::write_guard g(mutex_);
        smesh_io_.erase_all();
        fmesh_io_.erase_all();
        chunk_io_.erase_all();

        for ( uint32_t i = 0; i < 9; ++i )
        {
            std::set<vec3u> to_remesh;
            swap_to_remesh(to_remesh,i);
        }
    }



}; // class interactive_mesh

} // namespace mesh
} // namespace zi

#endif // ZI_MESHING_INTERACTIVE_MESH_HPP
