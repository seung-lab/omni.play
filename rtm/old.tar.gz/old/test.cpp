#include "scrum.hpp"
#include <zi/concurrency.hpp>
#include <iostream>

using namespace std;

zi::mesh::scrum s;
zi::mutex mt;

void tr(int i)
{
    while (1)
    {
        //zi::this_thread::sleep(1);
        {
            zi::mutex::guard g(mt);
            std::cout << i << ": pre-scrum\n";
        }
        s.arrive();
        {
            zi::mutex::guard g(mt);
            std::cout << i << ": after-scrum\n";
        }
    }
}

int main()
{

    zi::thread t[20];


    for ( int i = 0; i < 20; ++i )
    {
        t[i] = zi::thread(zi::run_fn(zi::bind(&tr, i)));
        t[i].start();
    }


    {
        zi::mutex::guard g(mt);
        std::cout << "Main summon(20)\n";
    }
    s.summon(20);
    {
        zi::mutex::guard g(mt);
        std::cout << "Main summon(20) done\n";
    }
    s.dismiss();
    {
        zi::mutex::guard g(mt);
        std::cout << "Main summon(20) released\n";
    }


    {
        zi::mutex::guard g(mt);
        std::cout << "Main summon(20)\n";
    }
    s.summon(20);
    {
        zi::mutex::guard g(mt);
        std::cout << "Main summon(20) done\n";
    }
    s.dismiss();
    {
        zi::mutex::guard g(mt);
        std::cout << "Main summon(20) released\n";
    }
    {
        zi::mutex::guard g(mt);
        std::cout << "Main summon(20)\n";
    }
    s.summon(20);
    {
        zi::mutex::guard g(mt);
        std::cout << "Main summon(20) done\n";
    }
    s.dismiss();
    {
        zi::mutex::guard g(mt);
        std::cout << "Main summon(20) released\n";
    }
    {
        zi::mutex::guard g(mt);
        std::cout << "Main summon(20)\n";
    }
    s.summon(20);
    {
        zi::mutex::guard g(mt);
        std::cout << "Main summon(20) done\n";
    }
    s.dismiss();
    {
        zi::mutex::guard g(mt);
        std::cout << "Main summon(20) released\n";
    }
    {
        zi::mutex::guard g(mt);
        std::cout << "Main summon(20)\n";
    }
    s.summon(20);
    {
        zi::mutex::guard g(mt);
        std::cout << "Main summon(20) done\n";
    }
    s.dismiss();
    {
        zi::mutex::guard g(mt);
        std::cout << "Main summon(20) released\n";
    }
    {
        zi::mutex::guard g(mt);
        std::cout << "Main summon(20)\n";
    }
    s.summon(20);
    {
        zi::mutex::guard g(mt);
        std::cout << "Main summon(20) done\n";
    }
    s.dismiss();
    {
        zi::mutex::guard g(mt);
        std::cout << "Main summon(20) released\n";
    }
    {
        zi::mutex::guard g(mt);
        std::cout << "Main summon(20)\n";
    }
    s.summon(20);
    {
        zi::mutex::guard g(mt);
        std::cout << "Main summon(20) done\n";
    }
    s.dismiss();
    {
        zi::mutex::guard g(mt);
        std::cout << "Main summon(20) released\n";
    }


    int x;
    std::cin >> x;
}
