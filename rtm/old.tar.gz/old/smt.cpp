#include "interactive_mesh.hpp"

int main()
{
    zi::mesh::smesh_io s(10);
}
