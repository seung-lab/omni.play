//
// Copyright (C) 2012  Aleksandar Zlateski <zlateski@mit.edu>
// ----------------------------------------------------------
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

#ifndef ZI_MESHING_COMPRESS_HPP
#define ZI_MESHING_COMPRESS_HPP

#include "types.hpp"

#include <algorithm>

namespace zi {
namespace mesh {

namespace detail {

inline uint16_t
compress_recursive( const chunk_type& c, uint32_t x, uint32_t y, uint32_t w,
                    std::vector<uint16_t>& out )
{
    if ( w == 1 )
    {
        return c[x][y][z] ? 2 : 0;
    }

    uint32_t whalf = w >> 1;

    uint16_t r = 0;

    for ( uint32_t i = 0; i < 2; ++i )
    {
        for ( uint32_t j = 0; j < 2; ++j )
        {
            for ( uint32_t k = 0; k < 2; ++k )
            {
                r <<= 2;
                r |= compress_recursive(c,x+i*whalf,y+j*whalf,z+k*whalf,whalf);
            }
        }
    }


}

} // namespace detail

inline void
compress( const chunk_type& c, uint32_t w, std::vector<uint16_t>& out )
{
    detail::compress_recursive(c, 0, 0, 0, CHUNK_SIZE, out);
    std::reverse(out.begin(), out.end());
}

} // namespace mesh
} // namespace zi



#endif // ZI_MESHING_COMPRESS_HPP
